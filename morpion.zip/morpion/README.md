# MORPION 

#### par Abraham GAULT

Voici un projet de __morpion__. Le jeu en lui-même a été réalisé pour un projet guidé en cours de __NSI__.
Le système de __score__ a été ajouté à l'occasion d'un autre projet en NSI impliquant un __algorithme de tri__ et des __opérations fichiers__.

## Le fichier main

Ce fichier contient les __4 fonctions__ permettant aux joueurs de *jouer*. 
Le plateau est notamment fait à partir d'une liste de liste contenant des points que les joueurs modifieront en X ou O.

## La classe Profil



## La fonction tri

L'algorithme derrière la __fonction__ tri est un algorithme de __tri fusion__ fait à partir de __pseudo-code__ trouvé sur [Wikipédia](https://fr.wikipedia.org/wiki/Tri_fusion).
Le __choix de l'algorithme__ importe *peu* en raison de la faible taille des __données__.

```python
from tri import tri

lst = [5, 6, 3, 1, 2]

print(tri(lst))
```

```bash
>>> [1, 2, 3, 5, 6]
```